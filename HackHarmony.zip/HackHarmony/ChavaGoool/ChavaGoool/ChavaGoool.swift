//
//  HackHarmonyApp.swift
//  HackHarmony
//
//  Created by Fernando Aguilar on 27/10/25.
//

import SwiftUI

@main
struct ChavaGoool: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}

//
//  Movilidad.swift
//  ChavaGoool
//
//  Created by CEDAM25 on 27/10/25.
//

import MapKit
import SwiftUI
import UIKit

struct Movilidad: View {
    @State private var directions: [String] = []
    @State private var showDirections = false
    
    var body: some View {
        VStack{
            MapView(directions: $directions)
            
            HStack{
                Button(action: {
                    
                }, label:{
                    Text("Direccion al Estadio")
                } )
                .disabled(directions.isEmpty)
                .padding()
                Button(action: {
                    
                }, label:{
                    Text("Seguridad")
                } )
                .disabled(directions.isEmpty)
                .padding()
                
            }
          }.sheet(isPresented: $showDirections, content: {
            VStack(spacing: 0) {
              Text("Directions")
                .font(.largeTitle)
                .bold()
                .padding()

              Divider().background(Color(UIColor.systemBlue))

              List(0..<self.directions.count, id: \.self) { i in
                Text(self.directions[i]).padding()
              }
            }
          })
    }
}

struct MapView: UIViewRepresentable {
    
    typealias UIViewType = MKMapView
    @Binding var directions: [String]
    
    func makeCoordinator() -> MapViewCoordinator {
        return MapViewCoordinator()
      }
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        
        let region = MKCoordinateRegion(center:CLLocationCoordinate2D(latitude: 19.30, longitude: -99.15034), span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.5))
        mapView.setRegion(region, animated: true)
        
        
        //Estadio Azteca
        let e1 = MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: 19.3030631959922, longitude: -99.15034531344982))
        
        //Estadio Guadalajara
        let e2 = MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: 20.6846671526423, longitude: -103.4629888202324))
        
        //Estadio Monterrey
        let e3 = MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: 25.66931147752912, longitude: -100.24410323655128))
        
        //Estadio Monterrey
        let u1 = MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: 19.48216659855735, longitude: -99.24468721297289))
        
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: u1)
        request.destination = MKMapItem(placemark: e1)
        request.transportType = .automobile
        
        let direcctions = MKDirections(request: request)
        direcctions.calculate { response, error in
            guard let route = response?.routes.first else { return }
            mapView.addAnnotations([u1 ,e1])
            mapView.addOverlay(route.polyline)
            mapView.setVisibleMapRect(
                route.polyline.boundingMapRect, edgePadding:UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20),animated: true)
            self.directions = route.steps.map { $0.instructions }.filter { !$0.isEmpty }
        }
        
        return mapView
    }
    
    func updateUIView(_ uiView: MKMapView, context: Context) {
    }
    class MapViewCoordinator: NSObject, MKMapViewDelegate {
      func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = .systemBlue
        renderer.lineWidth = 5
        return renderer
      }
    }
  
}

struct Movilidad_Previews : PreviewProvider{
    static var previews: some View{
        Movilidad()
    }
}

//
//  Seguridad.swift
//  ChavaGoool
//
//  Created by CEDAM25 on 27/10/25.
//


import MapKit
import SwiftUI
import UIKit

struct Seguridad: View {
    // 1
      @State private var items: [MKMapItem] = [
        createMapItem(name: "Base Coyoacan", latitude: 19.302091573479448, longitude: -99.14513773488878),
        createMapItem(name: "Cordinacion Territorial", latitude: 19.303356953020728, longitude: -99.14510335669567),
        createMapItem(name: "Jefatura Xotepingo", latitude: 19.30909970637255, longitude: -99.16284250433547),
        createMapItem(name: "Caseta Policia" , latitude: 19.296856392879, longitude: -99.15684976580783),
      ]
      
      // 2
      @State private var selectedItem: MKMapItem?

      var body: some View {
        VStack{
          Button("Volver"){
              
          }
        // 3
        Map(selection: $selectedItem) {
          // 4
          ForEach(items, id: \.self) { item in
            Marker(item: item)
          }
        }
        .overlay(alignment: .bottom) {
          // 5
          if let name = selectedItem?.name {
            Text(name)
              .foregroundStyle(.white)
              .padding(5)
              .background(
                RoundedRectangle(cornerRadius: 10)
                  .foregroundColor(.black.opacity(0.7))
              )
          }
        }
          
          }
      }

      // 6
      private static func createMapItem(name: String, latitude: Double, longitude: Double) -> MKMapItem {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let placemark = MKPlacemark(coordinate: coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = name
        return mapItem
      }
}

struct Seguridad_Previews : PreviewProvider{
    static var previews: some View{
        Seguridad()
    }
}

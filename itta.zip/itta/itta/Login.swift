//
//  Login.swift
//  itta
//
//  Created by CEDAM21 on 27/10/25.
//

import SwiftUI

struct Login: View {
    @State var name = ""
    @State var email = ""
    @State var password = ""
    @State var password_ = ""
    var body: some View {
        NavigationStack{
            VStack{
                Text("Itta")
                    .bold()
                    .font(.title)
                    .foregroundColor(.white)
                Spacer()
                HStack{
                    Text("Ingresa los siguientes datos:")
                        .foregroundColor(.white)
                    Spacer()
                }
                
                TextField("Nombre", text: $name)
                    .keyboardType(.default)
                    .padding()
                    .background(.white)
                    .cornerRadius(15)
                TextField("Correo electronico", text: $email)
                    .keyboardType(.emailAddress)
                    .padding()
                    .background(.white)
                    .cornerRadius(15)
                SecureField("Contraseña", text: $password)
                    .keyboardType(.default)
                    .padding()
                    .background(.white)
                    .cornerRadius(15)
                SecureField("Confirma tu contraseña", text: $password_)
                    .keyboardType(.default)
                    .padding()
                    .background(.white)
                    .cornerRadius(15)
                
                Spacer()
                HStack{
                    Text("¿Ya tienes una cuenta?")
                    NavigationLink(destination: Sign_in()){
                        Text("Accede aquí")
                            .foregroundColor(.white)
                    }
                }
            }
            .padding(20)
            .frame(maxWidth:.infinity, maxHeight: .infinity)
            .background(.ittaBackgraund)
        }
    }
}

#Preview {
    Login()
}

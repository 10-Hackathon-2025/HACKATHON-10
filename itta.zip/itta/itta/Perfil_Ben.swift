//
//  Perfil_Ben.swift
//  itta
//
//  Created by CEDAM21 on 27/10/25.
//

import SwiftUI

struct Perfil_Ben: View {
    var body: some View {
          VStack{
              HStack{
                  Text("itta!")
                      .bold()
                      .font(.title)
                      .foregroundColor(.white)
                  Spacer()
                  Text("Beneficiario")
                      .font(.title3)
                      .foregroundColor(.white)
              }
              .padding()
              .background(Color.ittaBackgraund)
              HStack{
                  Button(action: {
                  }) {
                      Spacer()
                      Text("Editar")
                          .foregroundColor(.blue)
                  }
              }
              .padding()
              AsyncImage(url: URL(string: "https://picsum.photos/200"))
                  .frame(width: 200, height: 200)
                  .cornerRadius(40)
              Text("Noah Jhonson")
                  .bold()
                  .font(.title)
              //Info personal
              VStack(alignment: .leading){
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "person.circle")
                              .foregroundColor(.white)
                      }
                      Text("Jhonson Perez Noah")
                          .font(.headline)
                          .padding(.bottom, 5)
                  }
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "envelope")
                              .foregroundColor(.white)
                      }
                      Text("noah.Jhon@gmail.com")
                          .font(.headline)
                          .padding(.bottom, 5)
                  }
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "person.fill.checkmark")
                              .foregroundColor(.white)
                      }
                      Text("Ingles")
                          .font(.headline)
                  }
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "books.vertical")
                              .foregroundColor(.white)
                      }
                      Text("México vs Croacia")
                          .font(.headline)
                  }
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "creditcard")
                              .foregroundColor(.white)
                      }
                      Text("200%")
                          .font(.headline)
                  }
              }
                  .padding()
                  .background(Color(UIColor.systemGray6))
                  .cornerRadius(10)
              
              Spacer()
          }
      }
  }

#Preview {
    Perfil_Ben()
}


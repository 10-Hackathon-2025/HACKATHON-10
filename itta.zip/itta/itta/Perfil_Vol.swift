//
//  Perfil_Vol.swift
//  itta
//
//  Created by CEDAM21 on 27/10/25.
//

import SwiftUI

struct Perfil_Vol: View {
    var body: some View {
          VStack{
              HStack{
                  Text("itta!")
                      .bold()
                      .font(.title)
                      .foregroundColor(.white)
                  Spacer()
                  Text("Voluntario")
                      .font(.title3)
                      .foregroundColor(.white)
              }
              .padding()
              .background(Color.ittaBackgraund)
              HStack{
                  Button(action: {
                  }) {
                      Spacer()
                      Text("Editar")
                          .foregroundColor(.blue)
                  }
              }
              .padding()
              AsyncImage(url: URL(string: "https://picsum.photos/200"))
                  .frame(width: 200, height: 200)
                  .cornerRadius(40)
              Text("Loera Gustavo")
                  .bold()
                  .font(.title)
              //Info personal
              VStack(alignment: .leading){
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "person.circle")
                              .foregroundColor(.white)
                      }
                      Text("Segura Loera Carlos Gustavo")
                          .font(.headline)
                          .padding(.bottom, 5)
                  }
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "envelope")
                              .foregroundColor(.white)
                      }
                      Text("calculDiferencial@gmail.com")
                          .font(.headline)
                          .padding(.bottom, 5)
                  }
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "person.fill.checkmark")
                              .foregroundColor(.white)
                      }
                      Text("Español / Ingles / Aleman")
                          .font(.headline)
                  }
                  HStack{
                      ZStack {
                          Rectangle()
                              .foregroundColor(.gray)
                              .frame(width: 25, height: 25)
                              .cornerRadius(5)
                          Image(systemName: "books.vertical")
                              .foregroundColor(.white)
                      }
                      Text("México vs Croacia")
                          .font(.headline)
                  }
              }
                  .padding()
                  .background(Color(UIColor.systemGray6))
                  .cornerRadius(10)
              
              Spacer()
          }
      }
  }

#Preview {
    Perfil_Vol()
}

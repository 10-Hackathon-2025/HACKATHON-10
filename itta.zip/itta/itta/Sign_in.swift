//
//  Sign_in.swift
//  itta
//
//  Created by CEDAM21 on 27/10/25.
//

import SwiftUI

struct Sign_in: View {
    @State var name = ""
    @State var password = ""
    var body: some View {
        NavigationStack{
            VStack{
                Spacer()
                Text("Itta")
                    .bold()
                    .font(.title)
                    .foregroundColor(.white)
                Text("¡Bienvenido!")
                    .bold()
                    .font(.title2)
                    .foregroundColor(.white)
                
                TextField("Ingresa tu nombre", text: $name)
                    .keyboardType(.default)
                    .padding()
                    .background(.white)
                    .cornerRadius(15)
                SecureField("Ingresa tu contraseña", text: $password)
                    .keyboardType(.default)
                    .padding()
                    .background(.white)
                    .cornerRadius(15)
                
                HStack{
                    Spacer()
                    Text("Olvidaste tu contraseña")
                        .foregroundColor(.white)
                }
                .padding(.horizontal)
                
                NavigationLink(destination: ContentView()){
                    Text("Ingresar")
                        .bold()
                        .font(.title2)
                }
                .padding()
                
                Spacer()
                HStack{
                    Text("¿No tienes una cuenta?")
                    
                    NavigationLink(destination: Login()){
                        Text("Registrate aquí")
                            .foregroundColor(.white)
                    }
                }
            }
            .padding(20)
            .frame(maxWidth:.infinity, maxHeight: .infinity)
            .background(.ittaBackgraund)
        }
    }
}

#Preview {
    Sign_in()
}

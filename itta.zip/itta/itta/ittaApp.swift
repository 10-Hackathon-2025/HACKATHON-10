//
//  ittaApp.swift
//  itta
//
//  Created by CEDAM21 on 27/10/25.
//

import SwiftUI

@main
struct ittaApp: App {
    var body: some Scene {
        WindowGroup {
            Sign_in()
        }
    }
}
